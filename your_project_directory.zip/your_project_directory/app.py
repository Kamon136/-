from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Список постов для хранения
posts = []
post_id = 1  # Для уникальных ID постов

@app.route('/')
def index():
    return render_template('index.html', posts=posts)

@app.route('/create', methods=['POST'])
def create_post():
    global post_id
    title = request.form['title']
    content = request.form['content']
    posts.append({'id': post_id, 'title': title, 'content': content})
    post_id += 1
    return redirect(url_for('index'))

@app.route('/delete/<int:post_id>', methods=['POST'])
def delete_post(post_id):
    global posts
    posts = [post for post in posts if post['id'] != post_id]
    return redirect(url_for('index'))

@app.route('/edit/<int:post_id>', methods=['GET', 'POST'])
def edit_post(post_id):
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        for post in posts:
            if post['id'] == post_id:
                post['title'] = title
                post['content'] = content
                break
        return redirect(url_for('index'))

    # Извлекаем пост для редактирования
    post_to_edit = next((post for post in posts if post['id'] == post_id), None)

    # Проверяем, нашли ли мы пост
    if post_to_edit is None:
        return "Пост не найден", 404

    return render_template('edit.html', post=post_to_edit)

if __name__ == '__main__':
    app.run(debug=True)